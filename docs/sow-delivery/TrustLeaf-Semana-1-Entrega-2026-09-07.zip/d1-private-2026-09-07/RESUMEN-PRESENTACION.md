# TrustLeaf — Resumen para presentación

## Material listo

1. TrustLeaf-dos-contratos.html: una pantalla con los dos contratos y explicación breve.
2. TrustLeaf-transacciones-de-prueba.html: cuatro transacciones enlazadas y controles de seguridad de ambos contratos.
3. TrustLeaf-mini-guion.md: texto breve para acompañar las láminas.
4. LEER-PRIMERO.md: matriz de cierre D1 y alcance de aceptación.
5. TrustLeaf-preguntas.html: doce preguntas frecuentes con respuestas desplegables para apoyar la presentación.

## Verificado

- 11 pruebas contractuales aprobadas: 4 del registro y 7 de recetas.
- 137 pruebas de aplicación aprobadas; TypeScript sin errores.
- Ambos binarios recompilados coinciden con sus hashes de Testnet.
- 4 transacciones del flujo confirmadas por lectura RPC.
- 6 envolturas fee-bump verificadas con pagador esperado.

## Mensaje de cierre

“Completamos la validación técnica de los dos contratos del entregable uno en Testnet y reunimos la evidencia de pruebas, despliegue y relay. La demostración utiliza datos sintéticos. El siguiente hito es el recorrido desde la interfaz.”

La aceptación formal corresponde al responsable de la entrega. No afirmar auditoría integral ni preparación clínica de producción.
